/* Sincronização Supabase opcional. Proteção efetiva depende das políticas RLS do backend. */
window.CECloud = (() => {
 const cfg=window.CADERNO_CONFIG||{};let token=localStorage.getItem('ce-cloud-token')||'',user=null;
 const status=(s)=>{const el=document.querySelector('#cloudStatus');if(el)el.textContent=s;const st=document.querySelector('#syncText');if(st)st.textContent=s};
 const configured=()=>/^https:\/\/.+/.test(cfg.SUPABASE_URL||'')&&!!cfg.SUPABASE_ANON_KEY;
 async function request(path,opts={}){
  if(!configured())throw new Error('Supabase não configurado. Edite config.js e aplique backend/supabase.sql.');
  const r=await fetch(cfg.SUPABASE_URL.replace(/\/$/,'')+path,{...opts,headers:{apikey:cfg.SUPABASE_ANON_KEY,Authorization:'Bearer '+(token||cfg.SUPABASE_ANON_KEY),'Content-Type':'application/json',...(opts.headers||{})}});
  const body=await r.text();let data;try{data=body?JSON.parse(body):null}catch{data=body}
  if(!r.ok)throw new Error(data?.msg||data?.message||data?.error_description||('Supabase HTTP '+r.status));
  return data;
 }
 async function signup(email,password){if(password.length<8)throw new Error('Use uma senha com pelo menos 8 caracteres.');const d=await request('/auth/v1/signup',{method:'POST',body:JSON.stringify({email,password})});if(d.access_token){token=d.access_token;localStorage.setItem('ce-cloud-token',token);user=d.user}status(d.access_token?'Conta criada e sessão iniciada.':'Conta criada. Confirme o e-mail antes de entrar.');return d}
 async function login(email,password){const d=await request('/auth/v1/token?grant_type=password',{method:'POST',body:JSON.stringify({email,password})});token=d.access_token;user=d.user;localStorage.setItem('ce-cloud-token',token);status('Conectado como '+(user.email||email));return d}
 async function logout(){token='';user=null;localStorage.removeItem('ce-cloud-token');status('Sessão encerrada.')}
 async function sync(){
  if(!navigator.onLine)throw new Error('Sem internet. Alterações permanecem salvas neste dispositivo.');
  if(!token)throw new Error('Entre na sua conta para sincronizar.');
  status('Sincronizando…');
  const tokenPayload=JSON.parse(atob(token.split('.')[1].replace(/-/g,'+').replace(/_/g,'/')));
  if(!tokenPayload.sub)throw new Error('Sessão inválida. Entre novamente.');
  const payload={user_id:tokenPayload.sub,data:Object.fromEntries(Object.keys(localStorage).filter(k=>k.startsWith('ce-')&&!['ce-cloud-token'].includes(k)).map(k=>[k,JSON.parse(localStorage.getItem(k)||'null')])),updated_at:new Date().toISOString()};
  await request('/rest/v1/user_backups?on_conflict=user_id',{method:'POST',headers:{Prefer:'resolution=merge-duplicates,return=minimal'},body:JSON.stringify(payload)});
  status('Sincronização concluída em '+new Date().toLocaleTimeString());
 }
 function init(){
  const bind=(id,fn)=>document.querySelector('#'+id)?.addEventListener('click',async()=>{try{await fn()}catch(e){status('Erro: '+e.message)}});
  bind('cloudSignup',()=>signup(document.querySelector('#cloudEmail').value,document.querySelector('#cloudPassword').value));
  bind('cloudLogin',()=>login(document.querySelector('#cloudEmail').value,document.querySelector('#cloudPassword').value));
  bind('cloudLogout',logout);bind('cloudSync',sync);
  if(!configured())status('Nuvem desativada até configurar config.js e o SQL do Supabase.');
  else status(token?'Sessão salva neste dispositivo.':'Supabase configurado. Faça login para sincronizar.');
 }
 if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',init);else init();
 return {signup,login,logout,sync,configured};
})();