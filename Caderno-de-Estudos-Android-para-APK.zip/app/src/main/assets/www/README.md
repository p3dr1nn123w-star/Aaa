# Caderno de Estudos — PWA

## O que foi implementado
- Preservadas as áreas e rotinas do HTML original (foco, matérias, tarefas, flashcards, notas, professor/IA, redação, PDFs e trabalhos).
- Interface responsiva, navegação móvel e manifesto instalável.
- Service Worker com cache do shell do aplicativo.
- IndexedDB para espelhamento persistente dos dados antigos e biblioteca Wikipédia.
- Biblioteca Wikipédia: pesquisa via API MediaWiki, resumo em português, salvar offline, favoritos, histórico e download seletivo por assunto com intervalo entre requisições.
- Exportação/importação de backup JSON.
- Integração opcional com Supabase Auth e sincronização de backup.

## Como executar
Service Worker e PWA exigem HTTPS ou `localhost`; abrir `index.html` diretamente por `file://` não ativa o modo PWA.
1. Extraia o ZIP.
2. Hospede a pasta em HTTPS (GitHub Pages, Netlify, Vercel ou servidor próprio), ou rode localmente:
   `python -m http.server 8000`
3. Abra `http://localhost:8000` no navegador.
4. No Android/Chrome use "Instalar aplicativo" ou "Adicionar à tela inicial".
5. No iPhone/iPad abra no Safari → Compartilhar → Adicionar à Tela de Início.

## Limitações importantes
- PWA offline: o shell do aplicativo fica em cache após a primeira abertura online. Artigos da Wikipédia só ficam offline depois de salvos. A API de pesquisa exige internet.
- A biblioteca salva o texto de resumo retornado pela API, metadados e link para o artigo; não baixa automaticamente a página completa nem todas as imagens. Imagens externas só estarão disponíveis offline se o navegador já as tiver armazenado; a licença de cada mídia deve ser conferida na página do arquivo.
- PDF.js e Google Fonts do projeto original continuam sendo dependências externas; em modo offline, PDFs novos podem não ser processados se a biblioteca não tiver sido previamente carregada. Os dados de estudo continuam acessíveis.
- Os recursos de IA existentes dependem do ambiente `window.claude` original e de internet; não foram substituídos por uma API de IA inventada. Para produção, mova as chamadas para um backend seguro.
- Supabase não fica ativo até configurar credenciais e executar o SQL abaixo. Não existe chave de serviço no front-end.
- Sincronização atual envia um snapshot dos dados locais para a linha autenticada. Não implementa resolução avançada de conflitos por campo nem recuperação automática de dados remotos; mantenha backups exportados.

## Configurar Supabase
1. Crie um projeto em https://supabase.com.
2. No painel, copie Project URL e a chave `anon`/`publishable`.
3. Edite `config.js` e preencha `SUPABASE_URL` e `SUPABASE_ANON_KEY`.
4. No SQL Editor execute `backend/supabase.sql`.
5. Em Authentication → URL Configuration, cadastre o domínio publicado.
6. Em Authentication → Providers, configure confirmação de e-mail conforme sua preferência.
7. Publique novamente e teste criar conta, entrar e sincronizar. Nunca use `service_role` no navegador.

## Licenças Wikipédia
O texto da Wikipédia é normalmente disponibilizado sob CC BY-SA (verifique a licença vigente e a página do artigo). Atribuição e link para histórico são exibidos. As imagens têm licenças próprias; este projeto não as baixa em lote. Consulte https://commons.wikimedia.org/wiki/Commons:Licensing.

## Testes realizados
- Verificação sintática do JavaScript com Node.js.
- Verificação de JSON do manifesto.
- Verificação estrutural de referências locais.
- Testes reais de instalação em Android/iOS, sincronização Supabase, modo avião e recuperação de conexão precisam ser feitos no domínio HTTPS e com conta/projeto de nuvem configurados.
