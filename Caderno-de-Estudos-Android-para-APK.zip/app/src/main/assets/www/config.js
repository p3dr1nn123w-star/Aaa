/* Configuração pública do cliente. Preencha somente com URL e chave ANON/PUBLISHABLE do Supabase. Nunca coloque service_role aqui. */
window.CADERNO_CONFIG = {
  SUPABASE_URL: "",
  SUPABASE_ANON_KEY: ""
};
