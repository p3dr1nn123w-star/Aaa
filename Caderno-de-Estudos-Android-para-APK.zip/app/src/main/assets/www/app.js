const $=s=>document.querySelector(s);
const store={
  get(k,d){try{const v=localStorage.getItem(k);return v?JSON.parse(v):d}catch(e){return d}},
  set(k,v){try{localStorage.setItem(k,JSON.stringify(v))}catch(e){}}
};

/* Abas */
document.querySelectorAll('nav button').forEach(b=>b.onclick=()=>{
  document.querySelectorAll('nav button').forEach(x=>x.setAttribute('aria-selected',x===b));
  document.querySelectorAll('section').forEach(s=>s.classList.toggle('on',s.id===b.dataset.t));
});

/* Foco */
let mins=25,left=1500,run=null;
const today=new Date().toISOString().slice(0,10);
let sessions=store.get('ce-sess',{});
const fmt=s=>String(Math.floor(s/60)).padStart(2,'0')+':'+String(s%60).padStart(2,'0');
function draw(){$('#time').textContent=fmt(left);document.title=run?fmt(left)+' · Estudos':'Caderno de Estudos';
  $('#sess').textContent='Sessões hoje: '+(sessions[today]||0)}
function beep(){try{const c=new (window.AudioContext||window.webkitAudioContext)(),o=c.createOscillator();o.connect(c.destination);o.frequency.value=660;o.start();o.stop(c.currentTime+.4)}catch(e){}}
function stop(){clearInterval(run);run=null;$('#go').textContent='Iniciar'}
$('#go').onclick=()=>{
  if(run){stop();draw();return}
  $('#go').textContent='Pausar';
  run=setInterval(()=>{left--;
    if(left<=0){stop();left=0;beep();if(mins===25){sessions[today]=(sessions[today]||0)+1;store.set('ce-sess',sessions);addXP(30)}}
    draw()},1000);
};
$('#reset').onclick=()=>{stop();left=mins*60;draw()};
document.querySelectorAll('#modes .chip').forEach(c=>c.onclick=()=>{
  document.querySelectorAll('#modes .chip').forEach(x=>x.setAttribute('aria-pressed',x===c));
  stop();mins=+c.dataset.m;left=mins*60;draw()});
draw();

/* Matérias */
const SUBJ={
"Português":{t:["Interpretação e gêneros textuais","Funções da linguagem","Variação linguística","Trovadorismo e Humanismo","Classicismo e Quinhentismo","Barroco","Classes de palavras"],
c:[["Função referencial da linguagem","Foco no assunto; informa de modo objetivo, como em uma notícia."],["Quem foi Camões?","Principal poeta do Classicismo português, autor de Os Lusíadas."],["Marca principal do Barroco","Contraste e conflito entre fé e razão, com linguagem exagerada."]]},
"Matemática":{t:["Conjuntos e intervalos","Função afim","Função quadrática","Função exponencial e logaritmo","Progressões (PA e PG)","Trigonometria no triângulo retângulo"],
c:[["Termo geral da PA","aₙ = a₁ + (n − 1)·r"],["Termo geral da PG","aₙ = a₁ · qⁿ⁻¹"],["Vértice da parábola (x)","xᵥ = −b / 2a"],["Seno, cosseno e tangente","sen = oposto/hipotenusa; cos = adjacente/hipotenusa; tg = oposto/adjacente"]]},
"Física":{t:["Grandezas e unidades do SI","Movimento uniforme","Movimento uniformemente variado","Queda livre e lançamentos","Vetores","Leis de Newton","Trabalho e energia"],
c:[["Função horária do MU","S = S₀ + v·t"],["Função horária do MUV","S = S₀ + v₀·t + a·t²/2"],["Segunda lei de Newton","F = m·a"]]},
"Química":{t:["Matéria e suas propriedades","Modelos atômicos","Tabela periódica","Ligações químicas","Funções inorgânicas","Reações e balanceamento"],
c:[["Cargas do próton, nêutron e elétron","Positiva, nula e negativa."],["Ligação iônica","Transferência de elétrons, normalmente entre metal e ametal."],["Solução ácida a 25 °C","Tem pH menor que 7."]]},
"Biologia":{t:["Origem da vida","Química da vida","Citologia: tipos de célula","Organelas","Fotossíntese e respiração celular","Mitose e meiose"],
c:[["Função da mitocôndria","Respiração celular, produzindo ATP."],["Procarionte x eucarionte","O eucarionte tem núcleo delimitado por membrana; o procarionte não."],["Resultado da meiose","Quatro células haploides geneticamente diferentes."]]},
"História":{t:["Pré-história e primeiras civilizações","Grécia e Roma antigas","Idade Média e feudalismo","Renascimento e Reformas","Grandes Navegações","Povos originários da América"],
c:[["Democracia ateniense","Cidadãos decidiam diretamente na assembleia; mulheres, escravizados e estrangeiros ficavam de fora."],["Feudalismo","Sistema baseado na terra, na servidão e na vassalagem."],["Renascimento","Movimento cultural dos séculos XIV a XVI que valorizou o humanismo e a razão."]]},
"Geografia":{t:["Cartografia e orientação","Coordenadas e fusos horários","Estrutura da Terra e relevo","Climas e biomas","Hidrografia","Questões ambientais"],
c:[["Latitude","Distância em graus ao norte ou ao sul do Equador (0° a 90°)."],["Meridiano de origem","Greenwich, com longitude 0°."],["Camadas da Terra","Crosta, manto e núcleo."]]},
"Filosofia":{t:["O que é filosofia","Mito e logos","Pré-socráticos","Sócrates, Platão e Aristóteles","Teoria do conhecimento","Ética"],
c:[["Maiêutica de Sócrates","Perguntas e diálogo que levam a pessoa a examinar as próprias ideias."],["Alegoria da caverna","Platão mostra a passagem da aparência ilusória ao conhecimento verdadeiro."],["Mito x logos","Mito explica o mundo por narrativas; logos, pela razão."]]},
"Sociologia":{t:["Surgimento da Sociologia","Durkheim, Weber e Marx","Cultura e identidade","Socialização","Instituições sociais","Desigualdade e estratificação"],
c:[["Fato social (Durkheim)","Modo de agir, pensar e sentir exterior ao indivíduo e que exerce coerção sobre ele."],["Etnocentrismo","Julgar outras culturas tomando a própria como superior."],["Ação social (Weber)","Ação humana com sentido atribuído pelo agente e orientada a outras pessoas."]]},
"Inglês":{t:["Verb to be","Simple Present","Present Continuous","Simple Past","Vocabulário e cognatos","Leitura de textos"],
c:[["Past tense of go","went"],["Estrutura do Present Continuous","am / is / are + verbo com -ing"],["Simple Present na 3ª pessoa","Acrescenta -s ou -es: she studies, he works."]]},
"Artes":{t:["Arte pré-histórica e antiga","Arte medieval","Renascimento","Barroco","Elementos da linguagem visual","Arte indígena e popular brasileira"],
c:[["Quem pintou a Mona Lisa?","Leonardo da Vinci, no Renascimento."],["Aleijadinho","Escultor e arquiteto do Barroco mineiro."]]},
"Educação Física":{t:["Corpo e saúde","Esportes coletivos","Ginástica","Dança","Capacidades físicas","Lutas"],
c:[["Capacidades físicas","Força, resistência, flexibilidade, velocidade e agilidade."],["Benefício da atividade física regular","Melhora a saúde do coração, o humor, o sono e a disposição."]]}
};
SUBJ["Espanhol"]={t:["Alfabeto e pronúncia","Saludos y presentaciones","Artículos e gênero dos substantivos","Presente do indicativo","Verbos ser, estar e tener","Falsos amigos"],
c:[["Como se diz obrigado em espanhol?","Gracias."],["Falso amigo: exquisito","Significa delicioso ou requintado, não esquisito."],["Artigos definidos em espanhol","el, la, los, las."]]};
SUBJ["Literatura"]={t:["Gêneros literários","Trovadorismo","Humanismo","Classicismo","Quinhentismo","Barroco e Arcadismo"],
c:[["Cantiga de amigo","Poema trovadoresco em que o eu lírico é feminino e sofre pela ausência do amado."],["Quinhentismo","Literatura de informação e catequese produzida no Brasil colonial do século XVI."],["Arcadismo","Escola literária do século XVIII que valoriza a simplicidade, a natureza e a razão."]]};
SUBJ["Redação"]={t:["Estrutura dissertativo-argumentativa","Tese e argumentos","Coesão e conectivos","Proposta de intervenção","As 5 competências do ENEM","Repertório sociocultural"],
c:[["Elementos da proposta de intervenção no ENEM","Agente, ação, meio ou modo, finalidade e detalhamento."],["Quantas competências o ENEM avalia na redação?","Cinco, de 0 a 200 pontos cada, totalizando até 1000."],["Função da tese","Apresentar a opinião central que o texto vai defender."]]};
const names=Object.keys(SUBJ);
function fill(sel,first){sel.innerHTML='';if(first){const o=document.createElement('option');o.value='';o.textContent=first;sel.append(o)}
  names.forEach(n=>{const o=document.createElement('option');o.value=o.textContent=n;sel.append(o)})}
fill($('#tSub'),'Geral');fill($('#fFilter'),'Todas as matérias');fill($('#fSub'));fill($('#nSub'),'Geral');
const go=t=>document.querySelector('nav [data-t="'+t+'"]').click();
let done=store.get('ce-topics',{}),cur=names[0];
function drawM(){
  const g=$('#subs');g.innerHTML='';
  names.forEach(n=>{
    const tot=SUBJ[n].t.length,k=SUBJ[n].t.filter((_,i)=>done[n+'|'+i]).length;
    const b=document.createElement('button');b.className='sb';b.setAttribute('aria-pressed',n===cur);
    b.innerHTML='<b></b><small></small><span class="bar"><i></i></span>';
    b.children[0].textContent=n;b.children[1].textContent=k+' de '+tot+' conteúdos';
    b.children[2].firstChild.style.width=(100*k/tot)+'%';
    b.onclick=()=>{cur=n;drawM()};g.append(b)});
  $('#mTitle').textContent=cur+': conteúdos do ano';
  const ul=$('#mList');ul.innerHTML='';
  SUBJ[cur].t.forEach((t,i)=>{
    const key=cur+'|'+i,li=document.createElement('li');li.className='t'+(done[key]?' done':'');
    const cb=document.createElement('input');cb.type='checkbox';cb.checked=!!done[key];cb.setAttribute('aria-label','Estudado: '+t);
    cb.onchange=()=>{done[key]=cb.checked;store.set('ce-topics',done);drawM()};
    const x=document.createElement('span');x.className='x';x.textContent=t;li.append(cb,x);ul.append(li)});
}
$('#mFc').onclick=()=>{$('#fFilter').value=cur;ci=0;flip=false;drawC();go('cards')};
$('#mNt').onclick=()=>{$('#nSub').value=cur;loadN();go('notas')};

/* Tarefas */
let tasks=store.get('ce-tasks',[{t:'Revisar o conteúdo da última aula',s:'Geral',d:false}]);
function drawT(){
  const ul=$('#tList');ul.innerHTML='';
  tasks.forEach((k,i)=>{
    const li=document.createElement('li');li.className='t'+(k.d?' done':'');
    const cb=document.createElement('input');cb.type='checkbox';cb.checked=k.d;cb.setAttribute('aria-label','Concluir: '+k.t);
    cb.onchange=()=>{k.d=cb.checked;store.set('ce-tasks',tasks);drawT()};
    const x=document.createElement('span');x.className='x';x.textContent=k.t;li.append(cb,x);
    if(k.s){const g=document.createElement('span');g.className='tag';g.textContent=k.s;li.append(g)}
    const d=document.createElement('button');d.className='del';d.textContent='×';d.setAttribute('aria-label','Excluir tarefa');
    d.onclick=()=>{tasks.splice(i,1);store.set('ce-tasks',tasks);drawT()};li.append(d);ul.append(li)});
  const n=tasks.filter(k=>k.d).length;
  $('#tCount').textContent=tasks.length?n+' de '+tasks.length+' concluídas':'Nenhuma tarefa ainda. Adicione a primeira acima.';
}
function addT(){const v=$('#tIn').value.trim();if(!v)return;
  tasks.push({t:v,s:$('#tSub').value,d:false});store.set('ce-tasks',tasks);$('#tIn').value='';drawT()}
$('#tAdd').onclick=addT;$('#tIn').onkeydown=e=>{if(e.key==='Enter')addT()};

/* Flashcards */
let cards=store.get('ce-cards2',null);
if(!cards){cards=[];names.forEach(n=>SUBJ[n].c.forEach(([q,a])=>cards.push({q,a,s:n})))}
let ci=0,flip=false;
const deck=()=>{const f=$('#fFilter').value;return cards.filter(c=>!f||c.s===f)};
function drawC(){
  const d=deck(),f=$('#fc');
  if(!d.length){f.textContent='Nenhum flashcard nesta matéria. Crie o primeiro abaixo.';f.className='fc';$('#fcCount').textContent='';return}
  ci=(ci+d.length)%d.length;
  f.textContent=flip?d[ci].a:d[ci].q;f.className='fc'+(flip?' back':'');
  $('#fcCount').textContent=(ci+1)+' / '+d.length+' · '+d[ci].s+(flip?' · resposta':'');
}
const save=()=>store.set('ce-cards2',cards);
$('#fc').onclick=()=>{flip=!flip;drawC()};
$('#next').onclick=()=>{ci++;flip=false;drawC()};
$('#prev').onclick=()=>{ci--;flip=false;drawC()};
$('#fFilter').onchange=()=>{ci=0;flip=false;drawC()};
$('#shuf').onclick=()=>{for(let i=cards.length-1;i>0;i--){const j=Math.floor(Math.random()*(i+1));[cards[i],cards[j]]=[cards[j],cards[i]]}ci=0;flip=false;save();drawC()};
$('#fdel').onclick=()=>{const d=deck();if(!d.length)return;cards.splice(cards.indexOf(d[ci]),1);flip=false;save();drawC()};
$('#fAdd').onclick=()=>{const q=$('#fQ').value.trim(),a=$('#fA').value.trim();if(!q||!a)return;
  const s=$('#fSub').value;cards.push({q,a,s});save();$('#fQ').value='';$('#fA').value='';
  $('#fFilter').value=s;ci=deck().length-1;flip=false;drawC()};

/* Notas */
let notes=store.get('ce-notes2',{});
if(!notes['']){const o=store.get('ce-notes','');if(o)notes['']=o}
const loadN=()=>{$('#nt').value=notes[$('#nSub').value]||'';$('#ntS').textContent=''};
$('#nSub').onchange=loadN;
$('#nt').oninput=e=>{notes[$('#nSub').value]=e.target.value;store.set('ce-notes2',notes);$('#ntS').textContent='Salvo. '+e.target.value.length+' caracteres.'};
/* Professor IA */
const pS=$('#pSub'),pT=$('#pTop');fill(pS);
function fillTop(){pT.innerHTML='';SUBJ[pS.value].t.forEach((t,i)=>{const o=document.createElement('option');o.value=i;o.textContent=t;pT.append(o)})}
pS.onchange=fillTop;fillTop();
let sample=null,lastExp='',quiz=null,ans=[],graded=false;
const SYS='Você é o Professor IA, um professor paciente e animado do 1º ano do Ensino Médio brasileiro. Responda em português do Brasil, em texto simples, sem markdown, sem asteriscos e sem #. Use parágrafos curtos.';
const topic=()=>SUBJ[pS.value].t[pT.value];
function busy(b){['pEx','pQz','pNext','pAsk'].forEach(id=>$('#'+id).disabled=b||(id==='pQz'&&!lastExp))}
function fail(el,e){el.textContent=e&&e.code==='rate_limited'?'Muitas solicitações em pouco tempo. Espere um instante e tente de novo.':e&&e.code==='not_granted'?'Você precisa permitir o uso do Claude para o professor funcionar.':'Não consegui falar com o professor agora. Tente de novo.'}
async function explain(){
  $('#pQuiz').innerHTML='';$('#pAns').textContent='';quiz=null;lastExp='';busy(true);
  const out=$('#pOut');out.textContent='O professor está preparando a aula...';
  try{
    const r=await sample(SYS+'\n\nExplique "'+topic()+'" ('+pS.value+') para um aluno do 1º ano do Ensino Médio. Comece com a ideia central em uma frase, explique passo a passo com 2 exemplos (do dia a dia ou resolvidos) e termine com "Resumo:" em 3 tópicos curtos. No máximo 350 palavras.',{onText:({text})=>{out.textContent=text}});
    lastExp=r.text;out.textContent=r.text;
  }catch(e){fail(out,e)}
  busy(false);
}
async function makeQuiz(){
  busy(true);graded=false;ans=[];const box=$('#pQuiz');box.textContent='Montando a prova...';
  try{
    const q=await sample.json(SYS+'\n\nCrie 5 questões de múltipla escolha, em estilo ENEM simplificado, sobre "'+topic()+'" ('+pS.value+'), com base nesta explicação:\n'+lastExp+'\n\nResponda SOMENTE com JSON: um array de 5 objetos {"pergunta":string,"alternativas":[4 strings sem letras],"correta":índice de 0 a 3,"explicacao":string curta}. Varie a posição da resposta correta.',{cache:false});
    if(!Array.isArray(q)||!q.length)throw 0;
    quiz=q;drawQ();
  }catch(e){fail(box,e)}
  busy(false);
}
function drawQ(){
  const box=$('#pQuiz');box.innerHTML='';
  quiz.forEach((q,i)=>{
    const d=document.createElement('div');d.className='q';
    const p=document.createElement('p');p.textContent=(i+1)+'. '+q.pergunta;d.append(p);
    q.alternativas.forEach((a,j)=>{
      const b=document.createElement('button');
      let c='opt';if(graded){if(j===q.correta)c+=' ok';else if(ans[i]===j)c+=' no'}else if(ans[i]===j)c+=' sel';
      b.className=c;b.textContent=(ans[i]===j?'( X )  ':'(    )  ')+'ABCD'[j]+') '+a;
      b.onclick=()=>{if(!graded){ans[i]=j;drawQ()}};d.append(b)});
    if(graded){const f=document.createElement('div');f.className='fb';f.textContent=q.explicacao||'';d.append(f)}
    box.append(d)});
  if(!graded){
    const g=document.createElement('button');g.className='btn';g.textContent='Corrigir prova';
    g.onclick=()=>{if(quiz.some((_,i)=>ans[i]===undefined)){g.textContent='Marque X em todas as questões';return}
      graded=true;const n=quiz.filter((q,i)=>ans[i]===q.correta).length;drawQ();addXP(n*10);
      const s=document.createElement('div');s.className='score';
      s.textContent='Você acertou '+n+' de '+quiz.length+'. '+(n/quiz.length>=0.6?'Conteúdo marcado como estudado!':'Releia a explicação e tente de novo.');
      box.append(s);
      if(n/quiz.length>=0.6){done[pS.value+'|'+pT.value]=true;store.set('ce-topics',done);drawM()}};
    box.append(g)}
}
$('#pEx').onclick=explain;
$('#pQz').onclick=makeQuiz;
$('#pNext').onclick=()=>{const i=+pT.value+1;
  if(i>=SUBJ[pS.value].t.length){pS.selectedIndex=(pS.selectedIndex+1)%names.length;fillTop()}else pT.value=i;explain()};
$('#pAsk').onclick=async()=>{
  const q=$('#pQ').value.trim(),out=$('#pAns');if(!q)return;busy(true);out.textContent='Pensando...';
  try{
    const r=await sample(SYS+'\n\nO aluno estudou "'+topic()+'" ('+pS.value+'). Explicação dada:\n'+lastExp+'\n\nDúvida do aluno: '+q+'\n\nResponda de forma clara e curta, com um exemplo se ajudar.',{cache:false,onText:({text})=>{out.textContent=text}});
    out.textContent=r.text;$('#pQ').value='';
  }catch(e){fail(out,e)}
  busy(false)};
(async()=>{try{sample=window.claude&&await window.claude.use('sample')}catch(e){}
  if(!sample){$('#pNo').hidden=false;$('#pBox').hidden=true}else busy(false)})();

/* Perfil, XP e sequência */
let prof=store.get('ce-prof',{xp:0,days:[],nome:'',ano:'1º ano'});
const iso=d=>d.toISOString().slice(0,10);
function streak(){let n=0,d=new Date();const s=new Set(prof.days);if(!s.has(iso(d)))d.setDate(d.getDate()-1);while(s.has(iso(d))){n++;d.setDate(d.getDate()-1)}return n}
function addXP(n){if(n<=0)return;prof.xp+=n;if(!prof.days.includes(today))prof.days.push(today);store.set('ce-prof',prof);drawS()}
function drawS(){
  const lv=Math.floor(Math.sqrt(prof.xp/50))+1,lo=50*(lv-1)**2,hi=50*lv**2;
  $('#hi').textContent=(prof.nome?'Olá, '+prof.nome+'! ':'Olá! ')+'Bons estudos hoje.';
  $('#stLv').textContent='Nível '+lv;$('#stXp').textContent=prof.xp+' XP';
  $('#stSt').textContent=streak()+' dias seguidos';
  $('#stH').textContent=(Object.values(sessions).reduce((a,b)=>a+b,0)*25/60).toFixed(1).replace('.',',')+' h de foco';
  $('#stT').textContent=names.reduce((a,n)=>a+SUBJ[n].t.filter((_,i)=>done[n+'|'+i]).length,0)+' de '+names.reduce((a,n)=>a+SUBJ[n].t.length,0)+' conteúdos';
  $('#stBar').style.width=Math.min(100,100*(prof.xp-lo)/(hi-lo))+'%';
}
const _dm=drawM;drawM=function(){_dm();drawS()};
$('#nome').value=prof.nome;$('#ano').value=prof.ano;
$('#nome').oninput=e=>{prof.nome=e.target.value;store.set('ce-prof',prof);drawS()};
$('#ano').onchange=e=>{prof.ano=e.target.value;store.set('ce-prof',prof)};

/* Professor ao vivo */
const CSYS='Você é o Professor IA de uma plataforma de estudos para o Ensino Médio brasileiro. Converse de forma natural, amigável, paciente e inteligente, como um professor particular que gosta de ensinar, sem tom de robô e sem formalidade exagerada. Explique em partes pequenas, com exemplos do cotidiano, e evite explicações gigantes quando uma simples resolve. De vez em quando faça uma pergunta curta para checar se o aluno entendeu e espere a resposta antes de seguir. Se o aluno errar, explique o erro sem julgar; se não entendeu, explique de outro jeito, com outras palavras e outro exemplo. Ao resolver exercícios, mostre o raciocínio passo a passo. Incentive a autonomia do aluno, elogie sem exagero e nunca o faça se sentir mal por errar. Adapte a linguagem e a dificuldade ao ano escolar e ao nível do aluno. Pode usar poucos emojis. Escreva em texto simples, sem markdown pesado (sem # e sem tabelas); escreva fórmulas em texto, como x² + 2x + 1. Se houver foto de exercício, leia o enunciado e guie o aluno na resolução.';
let chat=store.get('ce-chat',[]),img=null;
fill($('#cSub'),'Qualquer matéria');
const log=$('#cLog');
function bubble(r,t){const d=document.createElement('div');d.className='bub '+r;d.textContent=t;log.append(d);log.scrollTop=log.scrollHeight;return d}
function drawChat(){log.innerHTML='';
  if(!chat.length)bubble('ai','Oi! Eu sou seu professor. Mande uma dúvida, uma foto de exercício ou peça para começar um assunto do zero. Sobre o que vamos estudar hoje?');
  chat.forEach(m=>bubble(m.role==='user'?'me':'ai',m.content))}
function speak(t){if(!$('#cVoice').checked||!window.speechSynthesis)return;speechSynthesis.cancel();
  const u=new SpeechSynthesisUtterance(t.replace(/[\u{1F300}-\u{1FAFF}\u{2600}-\u{27BF}]/gu,''));u.lang='pt-BR';speechSynthesis.speak(u)}
async function send(){
  const t=$('#cIn').value.trim();if(!t&&!img)return;
  $('#cIn').value='';chat.push({role:'user',content:(t||'Pode me ajudar com o exercício da foto?')+(img?' [foto enviada]':'')});
  bubble('me',chat[chat.length-1].content);const out=bubble('ai','...');$('#cSend').disabled=true;
  const ctx='Aluno do '+prof.ano+' do Ensino Médio'+($('#cSub').value?', estudando '+$('#cSub').value:'')+'.';
  const msgs=chat.slice(-20);while(msgs.length&&msgs[0].role!=='user')msgs.shift();
  const input=msgs.map((m,i)=>({role:m.role,content:i?m.content:CSYS+'\n\n'+ctx+'\n\n'+m.content}));
  try{
    const r=await sample(input,{cache:false,images:img||undefined,onText:({text})=>{out.textContent=text}});
    out.textContent=r.text;chat.push({role:'assistant',content:r.text});chat=chat.slice(-60);store.set('ce-chat',chat);addXP(3);speak(r.text);
  }catch(e){fail(out,e);chat.pop()}
  img=null;$('#cFile').value='';$('#cAtt').textContent='';$('#cSend').disabled=false;log.scrollTop=log.scrollHeight;
}
$('#cSend').onclick=send;$('#cIn').onkeydown=e=>{if(e.key==='Enter')send()};
$('#cNew').onclick=()=>{chat=[];store.set('ce-chat',chat);drawChat()};
$('#cFile').onchange=e=>{img=e.target.files[0]||null;$('#cAtt').textContent=img?'Foto anexada: '+img.name:''};
drawChat();

/* Redação ENEM */
const COMP=['Domínio da norma culta','Compreensão do tema','Argumentação','Coesão textual','Proposta de intervenção'];
$('#rTxt').oninput=e=>{$('#rCnt').textContent=e.target.value.length+' caracteres'};
$('#rSug').onclick=async()=>{const b=$('#rSug');b.disabled=true;
  try{const r=await sample('Sugira UM tema de redação no estilo ENEM, atual e relevante para a sociedade brasileira, em uma única frase, começando com "Desafios para" ou "Caminhos para". Responda só com o tema.',{cache:false});$('#rTema').value=r.text.trim()}catch(e){fail($('#rOut'),e)}
  b.disabled=false};
$('#rGo').onclick=async()=>{
  const tx=$('#rTxt').value.trim(),o=$('#rOut');
  if(tx.length<400){o.textContent='Escreva pelo menos 400 caracteres para receber a correção.';return}
  $('#rGo').disabled=true;o.textContent='O corretor está lendo sua redação...';
  try{
    const r=await sample.json('Você é um corretor de redação do ENEM, educativo e gentil, que nunca humilha o aluno. Avalie a redação nas 5 competências, cada nota sendo 0, 40, 80, 120, 160 ou 200: (1) domínio da norma culta; (2) compreensão do tema e estrutura dissertativo-argumentativa; (3) seleção e organização de argumentos; (4) coesão; (5) proposta de intervenção. Seja honesto e explique pontos fortes e como melhorar. Responda SOMENTE com JSON: {"competencias":[{"nota":número,"fortes":string,"melhorar":string}] com 5 itens,"comentario":string,"proximosPassos":string}.\n\nTema: '+($('#rTema').value||'livre')+'\n\nRedação:\n'+tx,{cache:false});
    o.innerHTML='';const tot=r.competencias.reduce((a,c)=>a+(+c.nota||0),0);
    const s=document.createElement('div');s.className='score';s.textContent='Nota estimada: '+tot+' / 1000';o.append(s);
    r.competencias.forEach((c,i)=>{const d=document.createElement('div');d.className='rc';
      const h=document.createElement('b');h.textContent='Competência '+(i+1)+': '+COMP[i]+' ('+c.nota+'/200)';
      const a=document.createElement('p');a.textContent='Pontos fortes: '+c.fortes;
      const m=document.createElement('p');m.textContent='Para melhorar: '+c.melhorar;d.append(h,a,m);o.append(d)});
    const f=document.createElement('div');f.className='out';f.textContent=r.comentario+'\n\nPróximos passos: '+r.proximosPassos;o.append(f);
    const n=document.createElement('p');n.className='muted stat';n.textContent='Correção educativa feita por IA. Ela é uma estimativa e não substitui a correção oficial do ENEM.';o.append(n);
    addXP(40);
  }catch(e){fail(o,e)}
  $('#rGo').disabled=false};

(async()=>{
  let s=null,d=null;try{s=window.claude&&await window.claude.use('sample')}catch(e){}
  if(!s){['cNo','rNo'].forEach(i=>$('#'+i).hidden=false);['cBox','rBox'].forEach(i=>$('#'+i).hidden=true);return}
  try{const l=await s.limits();if(l&&l.images)$('#cPhoto').hidden=false}catch(e){}
  try{d=await window.claude.use('dictation')}catch(e){}
  if(d){const mic=$('#cMic');mic.hidden=false;
    d.onFinal(({text})=>{const t=$('#'+(window.micT||'cIn'));t.value=(t.value+' '+text).trim()});
    d.onState(({state})=>{if((window.micT||'cIn')==='cIn')mic.textContent=state==='listening'?'Parar':'Falar'});
    mic.onclick=()=>{window.micT='cIn';d.active()?d.stop():d.start({language:'pt-BR'}).catch(()=>{})}}
})();

/* Meu Amigo de Estudos */
let S=null,img2=null;
let am=store.get('ce-amigo',{nome:'Bê',av:'🦊',tom:'Divertido',mem:true});
let convs=store.get('ce-amigo-convs',[]),cid=convs.length?convs[0].id:null;
fill($('#aSub'),'Qualquer matéria');
const aLog=$('#aLog');
const ASYS='Você é o amigo de estudos de um aluno do Ensino Médio brasileiro. Você NÃO é o professor: o professor dá aulas completas; você acompanha, incentiva e ajuda o aluno a descobrir as respostas sozinho. Fale como um amigo inteligente que estuda junto: linguagem jovem e natural, bom humor na medida, sem tom de robô nem de professor formal, poucos emojis. Mensagens curtas, de 2 a 5 frases. REGRA PRINCIPAL: não entregue a resposta nem a resolução. Quando o aluno mandar uma questão: entenda o que ela pede; descubra onde está a dificuldade; dê UMA dica sutil e faça UMA pergunta que o ajude a raciocinar; espere a tentativa dele. Se continuar travado, dê uma dica mais específica, depois explique o conceito necessário sem dar o resultado. Quando ele acertar, explique por que o raciocínio funcionou. As dicas são progressivas, da mais sutil à mais detalhada. Só mostre a resolução completa se o aluno pedir de forma explícita para ver a explicação ou resolução completa. Adapte as dicas à matéria: na matemática, pistas sobre operações e raciocínio; na física, conceitos e fórmulas; na química, elementos e reações; na história, contexto e acontecimentos; no português, interpretação e regras gramaticais; na redação, sugira melhorias sem escrever o texto pelo aluno. Nunca julgue o aluno por errar, elogie sem exagero e mostre interesse pelo que ele está aprendendo. Se ele estiver desanimado, cansado ou com medo de ir mal, pare de ensinar: ouça, valide o sentimento sem minimizar, e ajude a escolher um próximo passo bem pequeno. Se ele falar em se machucar ou em desesperança grave, acolha com carinho e incentive a conversar com um adulto de confiança ou ligar para o CVV (188, gratuito, 24 horas). Escreva em texto simples, sem markdown pesado. Se houver foto de exercício, leia o enunciado e comece pela dica, não pela resposta.';
function memo(){
  const l=names.map(n=>{const k=SUBJ[n].t.filter((_,i)=>done[n+'|'+i]).length;return k?n+': '+k+' de '+SUBJ[n].t.length+' conteúdos estudados':null}).filter(Boolean);
  return (prof.nome?'Nome do aluno: '+prof.nome+'. ':'')+'Ano: '+prof.ano+'. Nível '+(Math.floor(Math.sqrt(prof.xp/50))+1)+', '+prof.xp+' XP, '+streak()+' dias seguidos. '+(l.length?l.join('; ')+'.':'Ainda não marcou conteúdos como estudados.')}
const cv=()=>convs.find(c=>c.id===cid);
const saveC=()=>store.set('ce-amigo-convs',convs);
function aBub(r,t){const d=document.createElement('div');d.className='bub '+r;d.textContent=t;aLog.append(d);aLog.scrollTop=aLog.scrollHeight;return d}
function drawA(){
  $('#aAv').textContent=am.av;$('#aHead').textContent=am.nome||'Meu amigo';
  const h=$('#aHist');h.innerHTML='';
  if(!convs.length){const o=document.createElement('option');o.textContent='Nenhuma conversa ainda';h.append(o)}
  convs.forEach(c=>{const o=document.createElement('option');o.value=c.id;o.textContent=c.t;h.append(o)});
  if(cid)h.value=cid;
  aLog.innerHTML='';const c=cv();
  if(!c||!c.m.length)aBub('ai','E aí! Eu sou o '+(am.nome||'seu amigo')+'. Vamos estudar junto? Me conta o que você está estudando ou manda a questão que está te pegando. Eu não vou te dar a resposta, mas prometo ajudar você a chegar nela.');
  else c.m.forEach(m=>aBub(m.role==='user'?'me':'ai',m.content));
}
function newConv(){const c={id:String(Date.now()),t:'Nova conversa',m:[]};convs.unshift(c);cid=c.id;saveC();drawA()}
function aSpeak(t){if(!$('#aVoice').checked||!window.speechSynthesis)return;speechSynthesis.cancel();
  const u=new SpeechSynthesisUtterance(t.replace(/[\u{1F300}-\u{1FAFF}\u{2600}-\u{27BF}]/gu,''));u.lang='pt-BR';speechSynthesis.speak(u)}
async function aSend(text){
  const t=(text||$('#aIn').value).trim();if(!t&&!img2)return;
  if(!S)return;
  if(!cv())newConv();
  const c=cv(),msg=(t||'Olha essa questão da foto.')+(img2?' [foto enviada]':'');
  $('#aIn').value='';c.m.push({role:'user',content:msg});
  if(c.t==='Nova conversa')c.t=msg.slice(0,32);
  saveC();drawA();const out=aBub('ai','...');$('#aSend').disabled=true;
  const ctx='Nome do amigo: '+(am.nome||'Bê')+'. Personalidade: '+am.tom.toLowerCase()+'. Aluno do '+prof.ano+' do Ensino Médio'+($('#aSub').value?', estudando '+$('#aSub').value:'')+'.'+(am.mem?' Progresso do aluno: '+memo():' O aluno preferiu não compartilhar o progresso.');
  const msgs=c.m.slice(-24);while(msgs.length&&msgs[0].role!=='user')msgs.shift();
  const input=msgs.map((m,i)=>({role:m.role,content:i?m.content:ASYS+'\n\n'+ctx+'\n\n'+m.content}));
  try{
    const r=await S(input,{cache:false,images:img2||undefined,onText:({text})=>{out.textContent=text}});
    out.textContent=r.text;c.m.push({role:'assistant',content:r.text});c.m=c.m.slice(-80);saveC();addXP(3);aSpeak(r.text);
  }catch(e){fail(out,e);c.m.pop();saveC()}
  img2=null;$('#aFile').value='';$('#aAtt').textContent='';$('#aSend').disabled=false;aLog.scrollTop=aLog.scrollHeight;
}
['Me dá uma dica?','Não entendi essa parte.','Me explica de outro jeito.','Me ajuda a pensar.','Estou desanimado.','Vamos estudar juntos?'].forEach(t=>{
  const b=document.createElement('button');b.className='chip';b.textContent=t;b.onclick=()=>aSend(t);$('#aChips').append(b)});
$('#aSend').onclick=()=>aSend();$('#aIn').onkeydown=e=>{if(e.key==='Enter')aSend()};
$('#aNew').onclick=newConv;
$('#aHist').onchange=e=>{cid=e.target.value;drawA()};
$('#aFile').onchange=e=>{img2=e.target.files[0]||null;$('#aAtt').textContent=img2?'Foto anexada: '+img2.name:''};
$('#aName').value=am.nome;$('#aAvS').value=am.av;$('#aTom').value=am.tom;$('#aMem').checked=am.mem;
const saveAm=()=>{store.set('ce-amigo',am);drawA()};
$('#aName').oninput=e=>{am.nome=e.target.value.trim();saveAm()};
$('#aAvS').onchange=e=>{am.av=e.target.value;saveAm()};
$('#aTom').onchange=e=>{am.tom=e.target.value;saveAm()};
$('#aMem').onchange=e=>{am.mem=e.target.checked;store.set('ce-amigo',am);$('#aSeeOut').textContent=''};
$('#aSee').onclick=()=>{$('#aSeeOut').textContent=am.mem?'O amigo vê isto: '+memo()+'\n\nAs conversas ficam salvas só neste navegador.':'A memória está desligada. O amigo não recebe seu progresso, apenas o que você escreve na conversa.'};
$('#aWipe').onclick=()=>{if(!convs.length)return;if(!$('#aWipe').dataset.ok){$('#aWipe').dataset.ok=1;$('#aWipe').textContent='Clique de novo para apagar tudo';return}
  convs=[];cid=null;saveC();delete $('#aWipe').dataset.ok;$('#aWipe').textContent='Apagar histórico de conversas';drawA()};
drawA();
(async()=>{
  let s=null,d=null;try{s=window.claude&&await window.claude.use('sample')}catch(e){}
  if(!s){$('#aNo').hidden=false;$('#aBox').hidden=true;return}
  S=s;
  try{const l=await s.limits();if(l&&l.images)$('#aPhoto').hidden=false}catch(e){}
  try{d=await window.claude.use('dictation')}catch(e){}
  if(d){const m=$('#aMic');m.hidden=false;
    d.onState(({state})=>{if(window.micT==='aIn')m.textContent=state==='listening'?'Parar':'Falar'});
    m.onclick=()=>{window.micT='aIn';d.active()?d.stop():d.start({language:'pt-BR'}).catch(()=>{})}}
})();

/* Central de Pesquisas */
const mk=(p,t,c,x)=>{const e=document.createElement(t);if(c)e.className=c;if(x)e.textContent=x;p.append(e);return e};
let docs=store.get('ce-pdfs',[]),pj=store.get('ce-proj',[]),curP=null,SP=null,DL=null,dh=[];const mem={};
const sv=()=>store.set('ce-proj',pj),sd=()=>store.set('ce-pdfs',docs);
const NOAI='O assistente só funciona quando o site é aberto pelo Claude.';
fill($('#wMat'));fill($('#sMat'),'Qualquer matéria');
function pv(v){$('#pHome').hidden=!!v;$('#pViews').hidden=!v;document.querySelectorAll('.pv').forEach(x=>x.hidden=x.id!=='v-'+v)}
document.querySelectorAll('.tile').forEach(t=>t.onclick=()=>pv(t.dataset.v));
$('#pBack').onclick=()=>{pv(null);drawPj()};

/* Projetos */
function drawPj(){
  const f=$('#pjF'),cur=f.value;f.innerHTML='';
  const o0=mk(f,'option','','Todas as pastas');o0.value='';
  [...new Set(pj.map(p=>p.pasta).filter(Boolean))].forEach(n=>{const o=mk(f,'option','',n);o.value=n});f.value=cur;
  const ul=$('#pjList');ul.innerHTML='';
  const L=pj.filter(p=>!f.value||p.pasta===f.value).sort((a,b)=>b.upd-a.upd);
  if(!L.length)mk(ul,'li','muted','Nenhum projeto ainda. Crie um trabalho ou gere um resumo.');
  L.forEach(p=>{
    const li=mk(ul,'li','t'),m=mk(li,'button','pjb');m.onclick=()=>openP(p);
    mk(m,'b','',p.titulo);mk(m,'small','',p.materia+' · '+p.tipo+(p.pasta?' · '+p.pasta:''));
    mk(li,'span','badge'+(p.status==='Salvo'?' ok':''),p.status);
    const r=mk(li,'button','btn alt small','Renomear');
    r.onclick=()=>{const i=document.createElement('input');i.value=p.titulo;i.setAttribute('aria-label','Novo nome');i.onkeydown=e=>{if(e.key==='Enter'){p.titulo=i.value.trim()||p.titulo;p.upd=Date.now();sv();drawPj()}};m.replaceWith(i);i.focus()};
    mk(li,'button','btn alt small','Duplicar').onclick=()=>{pj.push({...p,id:String(Date.now()),titulo:p.titulo+' (cópia)',status:'Rascunho',upd:Date.now()});sv();drawPj()};
    const x=mk(li,'button','btn alt small','Excluir');
    x.onclick=()=>{if(!x.dataset.c){x.dataset.c=1;x.textContent='Confirmar?';return}pj=pj.filter(q=>q!==p);sv();drawPj()}});
}
$('#pjF').onchange=drawPj;
function openP(p){curP=p.id;
  if(p.tipo==='Resumo'){pv('res');$('#rOut').textContent=p.texto;$('#rSave').hidden=true;return}
  pv('criar');$('#wMat').value=p.materia;$('#wAno').value=p.ano;$('#wTit').value=p.titulo;$('#wTxt').value=p.texto;$('#wPasta').value=p.pasta||'';$('#wEdit').hidden=false}
function saveW(st){
  let p=pj.find(x=>x.id===curP);
  if(!p){p={id:String(Date.now()),tipo:'Trabalho escolar'};pj.push(p);curP=p.id}
  Object.assign(p,{titulo:$('#wTit').value.trim()||'Trabalho sem título',materia:$('#wMat').value,ano:$('#wAno').value,texto:$('#wTxt').value,pasta:$('#wPasta').value.trim(),status:st,upd:Date.now()});sv()}

/* Criar trabalho */
$('#wGo').onclick=async()=>{
  const tema=$('#wTema').value.trim(),msg=$('#wMsg');
  if(!tema){msg.textContent='Escreva o tema do trabalho.';return}
  if(!SP){msg.textContent=NOAI;return}
  const d=docs.find(x=>x.id===$('#wRef').value),ori=$('#wOri').value.trim();
  $('#wGo').disabled=true;msg.textContent='Montando o trabalho...';curP=null;
  try{
    const r=await SP('Você ajuda um aluno do '+$('#wAno').value+' do Ensino Médio a elaborar um trabalho escolar de '+$('#wMat').value+' sobre "'+tema+'". Tamanho: '+$('#wTam').value+'. Formato: '+$('#wFmt').value+'. '+(ori?'Orientações do professor: '+ori+'. ':'')+'Escreva em linguagem natural e adequada ao Ensino Médio, bem organizada, com título, introdução, desenvolvimento com tópicos e subtópicos, conclusão e referências. Use "# " para o título, "## " para cada seção e "### " para subseções, parágrafos em texto simples e nenhum outro markdown. NÃO invente dados, estatísticas, autores, citações nem referências; se não tiver certeza de algo, escreva em termos gerais ou deixe de fora. Em Referências, liste apenas o documento de referência fornecido abaixo; se não houver, escreva: [Adicione aqui as fontes que você consultar, seguindo a ABNT]. Escreva a conclusão como um rascunho para o aluno reescrever com as próprias palavras.'+(d?'\n\nDocumento de referência: '+d.nome+'\n'+d.t.slice(0,50000):''),{cache:false});
    $('#wTxt').value=r.text.trim();const m=r.text.match(/^# (.+)$/m);$('#wTit').value=m?m[1]:tema;
    $('#wEdit').hidden=false;saveW('Rascunho');msg.textContent='Pronto! Leia, confira os fatos e reescreva com suas palavras. Use o Modo aprendizado para entender o texto.';addXP(15);
  }catch(e){fail(msg,e)}
  $('#wGo').disabled=false};
$('#wTxt').oninput=()=>{if(curP)saveW('Rascunho')};
$('#wSave').onclick=()=>{saveW('Salvo');$('#wMsg').textContent='Projeto salvo.'};
const LP={e:'Explique com palavras simples o que o aluno escreveu, parte por parte, e os conceitos usados. Não reescreva o texto dele.',c:'Aponte os trechos confusos ou vagos e explique por quê, com perguntas que ajudem o aluno a melhorar. Não reescreva por ele.',p:'Aponte trechos que soam genéricos, copiados ou decorados e oriente o aluno a reescrever com as próprias palavras, com um método passo a passo e um exemplo curto de reescrita de uma frase qualquer (não do texto dele). Explique como citar fontes. Não afirme que há plágio: você não consegue verificar isso.',m:'Sugira melhorias de estrutura, argumentos e conclusão, em tópicos curtos, sem escrever o texto pelo aluno.',t:'Crie 5 perguntas para o aluno testar se entendeu o assunto do próprio trabalho, sem dar as respostas.'};
$('#wAsk').onclick=async()=>{
  const msg=$('#wMsg');if(!SP){msg.textContent=NOAI;return}
  $('#wAsk').disabled=true;msg.textContent='Lendo seu trabalho...';
  try{const r=await SP('Você é um professor do Ensino Médio que ajuda o aluno a compreender o próprio trabalho, sem fazer o trabalho por ele. Responda em português, em texto simples. '+LP[$('#wLearn').value]+' Lembre o aluno de conferir os fatos em fontes confiáveis.\n\nMatéria: '+$('#wMat').value+'\n\nTrabalho:\n'+$('#wTxt').value,{cache:false,onText:({text})=>{msg.textContent=text}});msg.textContent=r.text}catch(e){fail(msg,e)}
  $('#wAsk').disabled=false};
function toHtml(){
  const esc=s=>s.replace(/&/g,'&amp;').replace(/</g,'&lt;'),toc=[];let h='';
  $('#wTxt').value.split('\n').forEach(l=>{if(/^### /.test(l))h+='<h3>'+esc(l.slice(4))+'</h3>';else if(/^## /.test(l)){toc.push(l.slice(3));h+='<h2>'+esc(l.slice(3))+'</h2>'}else if(!/^# /.test(l)&&l.trim())h+='<p>'+esc(l)+'</p>'});
  const t=esc($('#wTit').value);
  if(!$('#wAbnt').checked)return '<h1>'+t+'</h1>'+h;
  return '<div class="capa"><p>'+esc(prof.nome||'')+'</p><div><h1>'+t+'</h1><p style="text-align:center">'+esc($('#wMat').value+' · '+$('#wAno').value)+'</p></div><p>'+new Date().getFullYear()+'</p></div><div class="sum"><h2>Sumário</h2><ol>'+toc.map(x=>'<li>'+esc(x)+'</li>').join('')+'</ol></div>'+h}
$('#wPdf').onclick=()=>{
  let pa=$('#printArea');if(!pa){pa=document.createElement('div');pa.id='printArea';document.body.append(pa)}
  pa.innerHTML=toHtml();
  try{window.print()}catch(e){$('#wMsg').textContent='Não consegui abrir a impressão aqui. Tente o botão Baixar para Word.'}};
$('#wDoc').onclick=async()=>{
  try{await DL.save({filename:'trabalho.doc',data:'<html><head><meta charset="utf-8"><style>body{font-family:"Times New Roman";font-size:12pt;line-height:1.5}h1{font-size:16pt;text-align:center}h2{font-size:13pt}</style></head><body>'+toHtml()+'</body></html>'});$('#wMsg').textContent='Arquivo enviado. Ele abre no Word com título, seções e sumário.'}
  catch(e){$('#wMsg').textContent='Não consegui baixar o arquivo agora. Use Imprimir ou salvar em PDF.'}};

/* Meus PDFs */
async function readPdf(f){
  const lib=window.pdfjsLib;if(!lib)throw 0;
  lib.GlobalWorkerOptions.workerSrc='https://cdnjs.cloudflare.com/ajax/libs/pdf.js/3.11.174/pdf.worker.min.js';
  const pdf=await lib.getDocument({data:await f.arrayBuffer()}).promise;let t='';
  for(let i=1;i<=pdf.numPages;i++){const c=await(await pdf.getPage(i)).getTextContent();t+='[Página '+i+']\n'+c.items.map(x=>x.str).join(' ')+'\n\n'}
  return{pdf,n:pdf.numPages,t}}
async function pageImgs(pdf,n){const o=[];for(let i=1;i<=Math.min(n,5);i++){const p=await pdf.getPage(i),v=p.getViewport({scale:1.3}),c=document.createElement('canvas');c.width=v.width;c.height=v.height;await p.render({canvasContext:c.getContext('2d'),viewport:v}).promise;o.push(await new Promise(r=>c.toBlob(r,'image/jpeg',.7)))}return o}
$('#pdfIn').onchange=async e=>{
  for(const f of e.target.files){$('#pdfSt').textContent='Lendo '+f.name+'...';
    try{const r=await readPdf(f),d={id:String(Date.now()+Math.random()),nome:f.name.replace(/\.pdf$/i,''),n:r.n,t:r.t.slice(0,150000),on:true,scan:r.t.replace(/\[Página \d+\]|\s/g,'').length<60*r.n};
      mem[d.id]=r.pdf;docs.push(d);sd();idbPut('pdfs',{id:d.id,name:f.name,type:f.type||'application/pdf',blob:f,updatedAt:Date.now()}).catch(err=>console.warn('PDF não salvo offline:',err))}catch(x){$('#pdfSt').textContent='Não consegui ler '+f.name+'. Confira se é um PDF válido.';e.target.value='';drawPdf();return}}
  $('#pdfSt').textContent='';e.target.value='';drawPdf()};
function drawPdf(){
  const ul=$('#pdfList');ul.innerHTML='';
  if(!docs.length)mk(ul,'li','muted','Nenhum PDF enviado ainda.');
  docs.forEach((d,i)=>{const li=mk(ul,'li','t'),cb=document.createElement('input');cb.type='checkbox';cb.checked=d.on;cb.setAttribute('aria-label','Usar no chat: '+d.nome);cb.onchange=()=>{d.on=cb.checked;sd()};li.append(cb);
    mk(li,'span','x',d.nome+' · '+d.n+' págs'+(d.scan?' · digitalizado (leitura por imagem)':''));
    const x=mk(li,'button','del','×');x.setAttribute('aria-label','Excluir PDF');x.onclick=()=>{docs.splice(i,1);delete mem[d.id];sd();drawPdf()}});
  [['#rSrc','Texto colado abaixo'],['#wRef','Sem PDF de referência']].forEach(([s,first])=>{const el=$(s),v=el.value;el.innerHTML='';mk(el,'option','',first).value='';docs.forEach(d=>{mk(el,'option','',d.nome).value=d.id});el.value=v})}
const DSYS='Você responde perguntas de um aluno do Ensino Médio sobre documentos que ele enviou. Use o conteúdo dos documentos como fonte principal e indique sempre a página de onde tirou cada informação, no formato (nome do documento, p. X). Separe o que está no documento do que é complemento seu, marcando o complemento com "Complemento (fora do documento):". Se a resposta não estiver no documento, diga isso com clareza e não invente. Use linguagem simples e natural, em texto simples. Se o documento é digitalizado, leia as imagens das páginas anexadas.';
async function dAsk(q){
  q=(q||$('#dIn').value).trim();if(!q)return;
  const on=docs.filter(d=>d.on),log=$('#dLog');
  if(!SP){mk(log,'div','bub ai',NOAI);return}
  if(!on.length){mk(log,'div','bub ai','Envie um PDF e marque a caixinha dele para eu conversar sobre ele.');return}
  $('#dIn').value='';dh.push({role:'user',content:q});mk(log,'div','bub me',q);const out=mk(log,'div','bub ai','...');
  let imgs=[];try{for(const d of on.filter(d=>d.scan&&mem[d.id]))imgs=imgs.concat(await pageImgs(mem[d.id],d.n))}catch(e){}
  const ms=dh.slice(-12);while(ms.length&&ms[0].role!=='user')ms.shift();
  const input=ms.map((m,i)=>({role:m.role,content:i?m.content:DSYS+'\n\n'+on.map(d=>'=== Documento: '+d.nome+' ('+d.n+' páginas) ===\n'+d.t.slice(0,60000)).join('\n\n')+'\n\nPergunta do aluno: '+m.content}));
  try{const r=await SP(input,{cache:false,images:imgs.length?imgs:undefined,onText:({text})=>{out.textContent=text}});out.textContent=r.text;dh.push({role:'assistant',content:r.text})}
  catch(e){fail(out,e);dh.pop()}
  log.scrollTop=log.scrollHeight}
['Resume esse PDF para mim.','Quais são os pontos mais importantes?','Explica as palavras difíceis.','Quais perguntas podem cair na prova sobre esse conteúdo?'].forEach(t=>mk($('#dChips'),'button','chip',t).onclick=()=>dAsk(t));
$('#dSend').onclick=()=>dAsk();$('#dIn').onkeydown=e=>{if(e.key==='Enter')dAsk()};

/* Pesquisar na internet */
$('#sGo').onclick=async()=>{
  const q=$('#sQ').value.trim(),o=$('#sOut'),L=$('#sLinks');if(!q)return;
  L.innerHTML='';const e=encodeURIComponent;
  [['Google Acadêmico','https://scholar.google.com/scholar?hl=pt-BR&q='+e(q)],['SciELO','https://search.scielo.org/?q='+e(q)],['Sites do governo (gov.br)','https://www.google.com/search?q='+e(q+' site:gov.br')],['Universidades (edu.br)','https://www.google.com/search?q='+e(q+' site:edu.br')]].forEach(([n,u])=>{const a=mk(L,'a','btn alt small',n);a.href=u;a.target='_blank';a.rel='noopener noreferrer'});
  if(!SP){o.textContent=NOAI;return}
  $('#sGo').disabled=true;o.textContent='Montando o plano...';
  try{const r=await SP('Um aluno do '+prof.ano+' do Ensino Médio quer pesquisar "'+q+'"'+($('#sMat').value?' em '+$('#sMat').value:'')+'. Você NÃO tem acesso à internet agora e deve avisar isso no início. Monte um plano de pesquisa em texto simples: 1) quatro perguntas-chave; 2) seis palavras-chave de busca; 3) tipos de fontes confiáveis para esse tema (órgãos oficiais, universidades, publicações científicas) e instituições que costumam tratar do assunto, SEM inventar links, autores, datas ou citações; 4) como separar fato de opinião e conferir uma fonte; 5) como anotar para escrever com as próprias palavras.',{cache:false,onText:({text})=>{o.textContent=text}});o.textContent=r.text}catch(x){fail(o,x)}
  $('#sGo').disabled=false};

/* Resumos inteligentes */
const TP={'Resumo curto':'um resumo curto, de até 120 palavras','Resumo detalhado':'um resumo detalhado','Resumo por capítulos':'um resumo organizado por capítulos ou seções','Mapa mental':'um mapa mental em texto, com o tema central e ramos indentados com hífens','Fichamento':'um fichamento com tema, ideias principais, conceitos e dúvidas','Lista de conceitos':'uma lista de conceitos importantes, cada um com definição simples','Flashcards':'10 flashcards, cada um com uma linha "P: pergunta" e outra "R: resposta"','Perguntas e respostas':'8 perguntas e respostas para estudar','Guia de revisão':'um guia de revisão com o que estudar, na ordem, e erros comuns'};
Object.keys(TP).forEach(k=>mk($('#rTipo'),'option','',k).value=k);
let rLast=null;
$('#rGo').onclick=async()=>{
  const o=$('#rOut'),d=docs.find(x=>x.id===$('#rSrc').value),src=d?d.t.slice(0,60000):$('#rIn').value.trim();
  if(!src){o.textContent='Escolha um PDF ou cole um texto.';return}
  if(!SP){o.textContent=NOAI;return}
  $('#rGo').disabled=true;$('#rSave').hidden=true;o.textContent='Gerando...';
  try{const r=await SP('Com base somente no material abaixo, crie '+TP[$('#rTipo').value]+'. Nível: '+$('#rNiv').value.toLowerCase()+', para um aluno do '+prof.ano+' do Ensino Médio. Quando houver marcadores [Página N], indique as páginas usadas. Não invente informações que não estejam no material. Texto simples, sem markdown pesado.\n\nMaterial:\n'+src,{cache:false,onText:({text})=>{o.textContent=text}});
    o.textContent=r.text;rLast={t:$('#rTipo').value+' — '+(d?d.nome:'texto colado'),x:r.text};$('#rSave').hidden=false;addXP(10)}catch(e){fail(o,e)}
  $('#rGo').disabled=false};
$('#rSave').onclick=()=>{if(!rLast)return;pj.push({id:String(Date.now()),tipo:'Resumo',titulo:rLast.t,materia:'Geral',ano:prof.ano,texto:rLast.x,pasta:'',status:'Salvo',upd:Date.now()});sv();$('#rSave').hidden=true;$('#rOut').textContent+='\n\nSalvo nos projetos.'};

(async()=>{try{SP=window.claude&&await window.claude.use('sample')}catch(e){}
  try{DL=window.claude&&await window.claude.use('downloads')}catch(e){}
  if(!DL)$('#wDoc').hidden=true})();
pv(null);drawPdf();drawPj();

drawM();drawT();drawC();loadN();

/* ===== PWA + persistência local robusta ===== */
const DB_NAME='caderno-estudos-db', DB_VERSION=2;
let ceDB=null, deferredInstallPrompt=null;
function openCE_DB(){
  if(ceDB)return Promise.resolve(ceDB);
  return new Promise((resolve,reject)=>{
    if(!('indexedDB' in window)){reject(new Error('IndexedDB indisponível'));return}
    const req=indexedDB.open(DB_NAME,DB_VERSION);
    req.onupgradeneeded=()=>{const db=req.result;
      ['kv','wiki','pdfs','queue'].forEach(n=>{if(!db.objectStoreNames.contains(n))db.createObjectStore(n,{keyPath:'id'})});
    };
    req.onsuccess=()=>{ceDB=req.result;resolve(ceDB)};
    req.onerror=()=>reject(req.error);
  });
}
function idbPut(storeName,value){return openCE_DB().then(db=>new Promise((res,rej)=>{const tx=db.transaction(storeName,'readwrite');tx.objectStore(storeName).put(value);tx.oncomplete=()=>res(true);tx.onerror=()=>rej(tx.error)}))}
function idbGetAll(storeName){return openCE_DB().then(db=>new Promise((res,rej)=>{const r=db.transaction(storeName).objectStore(storeName).getAll();r.onsuccess=()=>res(r.result||[]);r.onerror=()=>rej(r.error)}))}
function idbDelete(storeName,id){return openCE_DB().then(db=>new Promise((res,rej)=>{const tx=db.transaction(storeName,'readwrite');tx.objectStore(storeName).delete(id);tx.oncomplete=()=>res(true);tx.onerror=()=>rej(tx.error)}))}
function setConn(state,label){
 const dot=$('#connectionDot'),txt=$('#connectionText');if(!dot||!txt)return;
 dot.className=state;txt.textContent=label;
}
function updateConnection(){setConn(navigator.onLine?'online':'offline',navigator.onLine?'Online — dados locais disponíveis':'Offline — modo de leitura e estudo ativo')}
window.addEventListener('online',()=>{updateConnection();if(window.CECloud)CECloud.sync().catch(()=>{})});
window.addEventListener('offline',updateConnection);updateConnection();
if('serviceWorker' in navigator && location.protocol!=='file:'){
 window.addEventListener('load',()=>navigator.serviceWorker.register('./sw.js').then(()=>{}).catch(e=>console.warn('SW:',e)));
}
window.addEventListener('beforeinstallprompt',e=>{e.preventDefault();deferredInstallPrompt=e;const b=$('#installApp');if(b)b.hidden=false});
$('#installApp')?.addEventListener('click',async()=>{if(!deferredInstallPrompt)return;deferredInstallPrompt.prompt();await deferredInstallPrompt.userChoice;deferredInstallPrompt=null;$('#installApp').hidden=true});
/* Mirror de todas as chaves antigas para IndexedDB, mantendo compatibilidade com o app original. */
const legacySet=store.set.bind(store);
store.set=(k,v)=>{legacySet(k,v);idbPut('kv',{id:k,value:v,updatedAt:Date.now()}).catch(e=>console.warn('Persistência local:',e))};
(async()=>{
 try{
  const rows=await idbGetAll('kv');
  for(const row of rows){if(localStorage.getItem(row.id)===null)localStorage.setItem(row.id,JSON.stringify(row.value))}
  for(const key of Object.keys(localStorage)){
    if(!rows.some(row=>row.id===key)){const value=store.get(key,null);await idbPut('kv',{id:key,value,updatedAt:Date.now()})}
  }
  /* Reassocia os arquivos PDF persistidos às conversas após reabrir o aplicativo. */
  if(Array.isArray(docs)&&typeof readPdf==='function'){
    const savedPdfs=await idbGetAll('pdfs');
    for(const meta of docs){const saved=savedPdfs.find(x=>x.id===meta.id);if(saved?.blob){try{mem[meta.id]=(await readPdf(new File([saved.blob],saved.name,{type:saved.type||'application/pdf'}))).pdf}catch(err){console.warn('PDF offline indisponível:',err)}}}
  }
 }catch(e){console.warn('Migração IndexedDB:',e)}
})();

/* ===== Biblioteca Wikipédia: API oficial, cache offline e atribuição ===== */
const WIKI_API='https://pt.wikipedia.org/w/api.php';
let wikiCurrent=null,wikiTab='saved';
const wikiCache=new Map();
function wikiStatus(t){const el=$('#wikiStatus');if(el)el.textContent=t}
function wikiEsc(s){return String(s||'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]))}
async function wikiRequest(params){
 const url=WIKI_API+'?'+new URLSearchParams({...params,format:'json',origin:'*'});
 const r=await fetch(url,{headers:{'Api-User-Agent':'CadernoDeEstudos/1.0 (educational PWA)'}});
 if(!r.ok)throw new Error('A Wikipédia respondeu com HTTP '+r.status);
 return r.json();
}
async function wikiSearch(q,limit=10){
 const d=await wikiRequest({action:'query',generator:'search',gsrsearch:q,gsrnamespace:0,gsrlimit:String(limit),prop:'pageimages|extracts|info',exintro:'1',explaintext:'1',pithumbsize:'240',inprop:'url'});
 return Object.values(d.query?.pages||{}).sort((a,b)=>(a.index||0)-(b.index||0)).map(p=>({id:String(p.pageid),title:p.title,extract:p.extract||'',thumb:p.thumbnail?.source||'',url:p.fullurl||('https://pt.wikipedia.org/wiki/'+encodeURIComponent(p.title.replace(/ /g,'_')))}));
}
async function wikiFull(title){
 const d=await wikiRequest({action:'query',titles:title,prop:'extracts|info|pageimages',explaintext:'1',exsectionformat:'plain',inprop:'url',piprop:'thumbnail',pithumbsize:'800'});
 const p=Object.values(d.query?.pages||{})[0];if(!p||p.missing)throw new Error('Artigo não encontrado');
 return {id:String(p.pageid),title:p.title,extract:p.extract||'',thumb:p.thumbnail?.source||'',url:p.fullurl||('https://pt.wikipedia.org/wiki/'+encodeURIComponent(p.title.replace(/ /g,'_'))),savedAt:Date.now(),license:'CC BY-SA 4.0 (texto da Wikipédia; verificar licença individual de mídias)',attribution:'Conteúdo da Wikipédia, autores identificados no histórico do artigo.',source:'Wikipédia em português'};
}
async function wikiList(){
 const [saved,favs,hist]=await Promise.all([idbGetAll('wiki'),idbGetAll('wiki'),idbGetAll('queue')]);
 return {saved,favs:favs.filter(x=>x.favorite),hist:hist.filter(x=>x.kind==='wiki-history').sort((a,b)=>b.at-a.at)};
}
function wikiResultCard(item){
 const d=document.createElement('div');d.className='wiki-result';
 if(item.thumb){const im=document.createElement('img');im.loading='lazy';im.src=item.thumb;im.alt='';d.append(im)}
 const meta=document.createElement('div');meta.className='wiki-meta';
 const h=document.createElement('b');h.textContent=item.title;const p=document.createElement('p');p.className='muted stat';p.textContent=(item.extract||'').slice(0,220);
 const b=document.createElement('button');b.className='btn alt small';b.type='button';b.textContent='Abrir artigo';b.onclick=()=>openWikiArticle(item.title);
 meta.append(h,p,b);d.append(meta);return d;
}
async function wikiRenderLists(){
 const target=$('#wikiSaved');if(!target)return;target.innerHTML='';
 const {saved,favs,hist}=await wikiList();$('#wikiStorage').textContent=saved.length+' artigos salvos · '+Math.round(JSON.stringify(saved).length/1024)+' KB estimados';
 let list=wikiTab==='saved'?saved:wikiTab==='fav'?favs:hist;
 if(!list.length){target.textContent=wikiTab==='saved'?'Nenhum artigo salvo ainda.':wikiTab==='fav'?'Nenhum favorito ainda.':'Nenhuma pesquisa recente.';return}
 list.sort((a,b)=>(b.savedAt||b.at||0)-(a.savedAt||a.at||0));
 list.forEach(item=>{
  const d=document.createElement('div');d.className='wiki-result';const m=document.createElement('div');m.className='wiki-meta';
  const title=document.createElement('b');title.textContent=item.title;
  const desc=document.createElement('p');desc.className='muted stat';desc.textContent=item.extract?.slice(0,160)||item.url||'';
  const open=document.createElement('button');open.className='btn alt small';open.textContent='Ler';open.onclick=()=>openWikiArticle(item.title,true);
  const del=document.createElement('button');del.className='btn alt small';del.textContent='Excluir';del.onclick=async()=>{await idbDelete('wiki',item.id);wikiRenderLists()};
  m.append(title,desc,open);if(wikiTab!=='history')m.append(del);d.append(m);target.append(d);
 });
}
async function openWikiArticle(title,preferSaved=false){
 wikiStatus('Carregando artigo…');$('#wikiArticle').textContent='Carregando…';
 try{
  let a=null;
  if(preferSaved){const all=await idbGetAll('wiki');a=all.find(x=>x.title===title)||null}
  if(!a&&navigator.onLine)a=await wikiFull(title);
  if(!a){const all=await idbGetAll('wiki');a=all.find(x=>x.title===title)||null}
  if(!a)throw new Error('Este artigo não está salvo. Conecte-se à internet para baixá-lo.');
  wikiCurrent=a;
  const art=$('#wikiArticle');art.innerHTML='';
  const h=document.createElement('h3');h.textContent=a.title;art.append(h);
  if(a.thumb){const im=document.createElement('img');im.src=a.thumb;im.alt='Imagem ilustrativa de '+a.title;im.loading='lazy';art.append(im)}
  const p=document.createElement('p');p.textContent=a.extract||'Resumo indisponível.';art.append(p);
  const source=document.createElement('div');source.className='wiki-attribution';
  source.textContent='Fonte: '+(a.source||'Wikipédia em português')+'. Texto sob licença CC BY-SA; atribuição aos autores da Wikipédia. Imagens podem ter licenças próprias — consulte a página de cada arquivo. ';
  const link=document.createElement('a');link.href=a.url;link.target='_blank';link.rel='noopener noreferrer';link.textContent='Abrir histórico e licenças na Wikipédia';source.append(link);art.append(source);
  $('#wikiSave').disabled=false;$('#wikiFavorite').disabled=false;
  const all=await idbGetAll('wiki');$('#wikiSave').textContent=all.some(x=>x.id===a.id)?'Salvo offline':'Salvar offline';
  $('#wikiFavorite').textContent=a.favorite?'★ Favorito':'☆ Favoritar';
  wikiStatus(navigator.onLine?'Artigo online':'Artigo disponível offline');
  await idbPut('queue',{id:'hist-'+a.id+'-'+Date.now(),kind:'wiki-history',title:a.title,url:a.url,at:Date.now(),extract:a.extract?.slice(0,180)});
  wikiRenderLists();
 }catch(e){wikiStatus('Não foi possível abrir');$('#wikiArticle').textContent=e.message}
}
$('#wikiSearch')?.addEventListener('submit',async e=>{
 e.preventDefault();const q=$('#wikiQuery').value.trim();if(!q)return;
 const out=$('#wikiResults');out.innerHTML='';wikiStatus('Pesquisando…');
 try{if(!navigator.onLine)throw new Error('Pesquisa exige internet. Artigos já salvos continuam disponíveis offline.');
  const items=await wikiSearch(q,10);if(!items.length){out.textContent='Nenhum artigo encontrado.';wikiStatus('Sem resultados');return}
  items.forEach(x=>out.append(wikiResultCard(x)));wikiStatus(items.length+' resultados');
  await idbPut('queue',{id:'hist-search-'+Date.now(),kind:'wiki-history',title:'Pesquisa: '+q,url:'https://pt.wikipedia.org/w/index.php?search='+encodeURIComponent(q),at:Date.now(),extract:'Pesquisa na Wikipédia'});
 }catch(err){out.textContent=err.message;wikiStatus('Erro na pesquisa')}
});
$('#wikiBatch')?.addEventListener('click',async()=>{
 const topic=$('#wikiTopic').value,count=Number($('#wikiBatchCount').value)||5,terms={
 'Matemática':'matemática álgebra geometria estatística','Física':'física mecânica energia ondas','Química':'química tabela periódica ligações químicas','Biologia':'biologia célula genética ecologia','História':'história Brasil história mundial','Geografia':'geografia clima cartografia geopolítica','Filosofia':'filosofia ética epistemologia','Sociologia':'sociologia sociedade cultura','Literatura':'literatura brasileira escolas literárias','Tecnologia':'tecnologia informática inovação','Programação':'programação algoritmos linguagens de programação','Astronomia':'astronomia planetas sistema solar','Medicina e ciências':'medicina saúde ciências biológicas'
 };
 const out=$('#wikiResults');out.innerHTML='';if(!navigator.onLine){out.textContent='Conecte-se à internet para baixar artigos.';return}
 $('#wikiBatch').disabled=true;wikiStatus('Preparando lote…');
 try{
  const items=await wikiSearch(terms[topic]||topic,count);
  for(let i=0;i<items.length;i++){
   wikiStatus('Baixando '+(i+1)+' de '+items.length+'…');
   try{const a=await wikiFull(items[i].title);await idbPut('wiki',a);const row=wikiResultCard(a);out.append(row)}
   catch(err){console.warn('Falha no artigo',items[i].title,err)}
   await new Promise(r=>setTimeout(r,350)); /* reduz pressão sobre a API */
  }
  wikiStatus('Lote concluído');wikiRenderLists();
 }catch(err){out.textContent=err.message;wikiStatus('Falha no lote')}
 finally{$('#wikiBatch').disabled=false}
});
$('#wikiSave')?.addEventListener('click',async()=>{
 if(!wikiCurrent)return;try{const a={...wikiCurrent,savedAt:Date.now()};await idbPut('wiki',a);$('#wikiSave').textContent='Salvo offline';wikiRenderLists()}catch(e){wikiStatus('Erro ao salvar artigo')}
});
$('#wikiFavorite')?.addEventListener('click',async()=>{
 if(!wikiCurrent)return;const a={...wikiCurrent,favorite:!wikiCurrent.favorite};wikiCurrent=a;
 const all=await idbGetAll('wiki');if(all.some(x=>x.id===a.id))await idbPut('wiki',a);
 else await idbPut('wiki',a);
 $('#wikiFavorite').textContent=a.favorite?'★ Favorito':'☆ Favoritar';wikiRenderLists();
});
[['wikiTabSaved','saved'],['wikiTabFav','fav'],['wikiTabHistory','history']].forEach(([id,tab])=>$('#'+id)?.addEventListener('click',()=>{wikiTab=tab;wikiRenderLists()}));
wikiRenderLists();

/* ===== Exportação/importação de backup ===== */
$('#exportData')?.addEventListener('click',async()=>{
 try{
  const kv=await idbGetAll('kv'),wiki=await idbGetAll('wiki');
  const backup={format:'caderno-estudos-backup-v1',createdAt:new Date().toISOString(),localStorage:Object.fromEntries(Object.keys(localStorage).map(k=>[k,store.get(k,null)])),indexedDB:{kv,wiki}};
  const blob=new Blob([JSON.stringify(backup,null,2)],{type:'application/json'}),url=URL.createObjectURL(blob),a=document.createElement('a');
  a.href=url;a.download='backup-caderno-de-estudos-'+new Date().toISOString().slice(0,10)+'.json';a.click();URL.revokeObjectURL(url);$('#backupStatus').textContent='Backup exportado.';
 }catch(e){$('#backupStatus').textContent='Não foi possível exportar: '+e.message}
});
$('#importData')?.addEventListener('change',async e=>{
 const f=e.target.files?.[0];if(!f)return;
 try{
  if(f.size>25*1024*1024)throw new Error('Arquivo maior que 25 MB.');
  const data=JSON.parse(await f.text());if(data.format!=='caderno-estudos-backup-v1')throw new Error('Formato de backup não reconhecido.');
  for(const [k,v] of Object.entries(data.localStorage||{}))store.set(k,v);
  for(const item of data.indexedDB?.wiki||[])await idbPut('wiki',item);
  $('#backupStatus').textContent='Backup importado. Recarregue a página para atualizar todas as telas.';
 }catch(err){$('#backupStatus').textContent='Falha ao importar: '+err.message}
 e.target.value='';
});

/* ===== Mantém interface atualizada e sinaliza limite de IA offline ===== */
const aiOfflineNotice='A inteligência artificial em tempo real exige conexão e o serviço de IA configurado. Seus dados, matérias, flashcards, tarefas, anotações e artigos salvos continuam acessíveis offline.';
if(!navigator.onLine){const no=document.createElement('p');no.className='muted stat';no.textContent=aiOfflineNotice;$('#biblioteca .card')?.prepend(no)}
