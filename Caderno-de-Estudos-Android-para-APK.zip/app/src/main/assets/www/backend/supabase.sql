-- Execute no SQL Editor do Supabase.
-- O token de usuário identifica a linha via auth.uid(); RLS impede acesso cruzado.
create table if not exists public.user_backups (
  user_id uuid primary key references auth.users(id) on delete cascade,
  data jsonb not null default '{}'::jsonb,
  updated_at timestamptz not null default now()
);
alter table public.user_backups enable row level security;
create policy "read own backup" on public.user_backups
 for select to authenticated using (auth.uid() = user_id);
create policy "insert own backup" on public.user_backups
 for insert to authenticated with check (auth.uid() = user_id);
create policy "update own backup" on public.user_backups
 for update to authenticated using (auth.uid() = user_id) with check (auth.uid() = user_id);
grant select, insert, update on public.user_backups to authenticated;
